<?php

return [
    'adminEmail' => 'villevald.vladislav.sleep@gmail.com',
    'senderEmail' => 'noreply@example.com',
    'senderName' => 'Velek mailer',
];

# Junior Web developer landing page

**Yii2 Framework**
**Webpack**

*HTML5/JS/SASS*

Hey there! This is my own landing page, ready to read your comments about it. db.php and node_modules excluded from repository
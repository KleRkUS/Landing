var name = document.getElementById('offer-name');
var email = document.getElementById('offer-email');
var details = document.getElementById('offer-details');
var submit = document.getElementById('offer-submit');


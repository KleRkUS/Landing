import './../styles/bundle.scss';
import './site/_triangle.js';
import './site/_scroll.js';
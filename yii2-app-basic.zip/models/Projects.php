<?php

namespace app\models;

use yii\db\ActiveRecord;

class Projects extends ActiveRecord
{
}